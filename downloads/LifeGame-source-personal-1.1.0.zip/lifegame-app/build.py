#!/usr/bin/env python3
"""Build the server-ready /lg/ folder with Python 3 only. No network or external packages."""
from pathlib import Path
import hashlib,json,re,shutil
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'src'/'personal'
DEST=ROOT/'dist'/'lg'
def sha(data):return hashlib.sha256(data).hexdigest()
def build():
    meta=json.loads((ROOT/'UPSTREAM-SNAPSHOT.json').read_text(encoding='utf-8'))
    inputs={name:(SRC/name).read_bytes() for name in meta['runtimeFiles']}
    fingerprints={name:sha(data) for name,data in inputs.items()}
    digest=sha(json.dumps(fingerprints,sort_keys=True,separators=(',',':')).encode())
    if DEST.exists():shutil.rmtree(DEST)
    DEST.mkdir(parents=True)
    for name,data in inputs.items():
        target=DEST/name;target.parent.mkdir(parents=True,exist_ok=True)
        if name=='sw.js':
            script=data.decode('utf-8')
            marker="k.startsWith('lifegame-personal-shell-')"
            if marker not in script:raise ValueError('Review the upstream service-worker cache prefix before building')
            version=re.search(r"const CACHE='([^']+)';",script)
            if not version:raise ValueError('Upstream cache declaration changed')
            replacement="const CACHE_PREFIX='lifegame-personal-deploy-'+encodeURIComponent(new URL(self.registration.scope).pathname)+'-shell-';\nconst CACHE=CACHE_PREFIX+'"+digest[:16]+"';"
            script=script[:version.start()]+replacement+script[version.end():]
            script=script.replace(marker,'k.startsWith(CACHE_PREFIX)')
            script=script.replace("caches.match(new URL('./index.html',scope).href)","caches.open(CACHE).then(cache=>cache.match(new URL('./index.html',scope).href))")
            script=script.replace("caches.match(event.request)","caches.open(CACHE).then(cache=>cache.match(event.request))")
            data=script.encode('utf-8')
        target.write_bytes(data)
    shutil.copyfile(ROOT/'DEPLOY.md',DEST/'DEPLOY.md')
    info={'edition':'LifeGame Personal','packageVersion':meta['packageVersion'],'upstreamCommit':meta['upstreamCommit'],'snapshotTimestamp':meta['snapshotTimestamp'],'sourceTreeSHA256':digest,'sourceMatchesSnapshot':fingerprints==meta['runtimeSHA256'],'dataFormat':'personal-1','dataSchema':2,'deploymentFolder':'lg/','adapter':'Only SW cache names, cleanup and reads are scoped to the deployment path; content hash versions the cache. Business logic, data keys and HTML unchanged.'}
    (DEST/'BUILD-INFO.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    files={str(p.relative_to(DEST)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(DEST.rglob('*')) if p.is_file()}
    (DEST/'PACKAGE-MANIFEST.json').write_text(json.dumps({'upstreamCommit':meta['upstreamCommit'],'files':files,'note':'Hashes cover every other file in lg/. This manifest does not hash itself.'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Built '+str(DEST)+' ('+str(len(files)+1)+' files); source '+digest)
if __name__=='__main__':build()
