"""Read-only independent audit of sealed LAB-015 primary evidence.

Reads only run artifacts and the three analyst-contract documents. Writes the
derived semantic audit; never opens participant browser profiles or app code.
"""
import collections
import datetime as dt
import hashlib
import json
import pathlib
import statistics
import zipfile
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

RUN = pathlib.Path(__file__).resolve().parent.parent
KEY = 'lifegame-flex-lab-my-v1'


def read(name):
    return json.loads((RUN / name).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def relative(path):
    return str(pathlib.Path(path).relative_to(RUN))


events = [json.loads(x) for x in (RUN / 'events.jsonl').read_text().splitlines()]
world = read('world.json')
seal = read('ORIGINAL-EVIDENCE-MANIFEST.json')
manifest = read('source-manifest.json')
provenance = read('execution-provenance.json')
summary = read('summary.json')
facts = read('FACTS.json')
source = read('experiment-source.json')
seal_errors = []
for name, meta in seal['files'].items():
    p = RUN / name
    if not p.is_file() or p.stat().st_size != meta['bytes'] or sha(p.read_bytes()) != meta['sha256']:
        seal_errors.append(name)

observations = {e['observation_id']: read(relative(e['snapshot'])) for e in events if e['kind'] == 'observation'}
actions = [e for e in events if e['kind'] == 'action']
starts = {(e['actor'], e['day'], e['step']): e for e in events if e['kind'] == 'action_started'}
action_errors = []
resolved_actions = []
for e in actions:
    c = e['command']
    before = observations[c['observation_id']]
    after = observations[e['observation_id']]
    st = starts.get((e['actor'], e['day'], e['step']))
    if not st or st['command'] != c or not e['success'] or e.get('error'):
        action_errors.append({'sequence': e['sequence'], 'problem': 'unpaired or unsuccessful'})
    for f in [e['before'], e['after']]:
        if not pathlib.Path(f).is_file():
            action_errors.append({'sequence': e['sequence'], 'problem': 'missing PNG'})
    if pathlib.Path(e['before']).stem != c['observation_id'] or pathlib.Path(e['after']).stem != e['observation_id']:
        action_errors.append({'sequence': e['sequence'], 'problem': 'PNG/ID mismatch'})
    element = next((x for x in before['elements'] if x['element'] == c.get('element')), None)
    if c['op'] == 'act' and not element:
        action_errors.append({'sequence': e['sequence'], 'problem': 'element not in before observation'})
    resolved_actions.append({'sequence': e['sequence'], 'actor': e['actor'], 'day': e['day'], 'step': e['step'], 'intent': c['intent'], 'operation': c.get('action', c['op']), 'value': c.get('value'), 'ui_target': element['label'] if element else 'scroll', 'before_observation_id': c['observation_id'], 'after_observation_id': e['observation_id'], 'success': e['success']})

days = []
trace_meta = []
runtime_hashes = collections.defaultdict(set)
trace_errors = []
snapshots = []
all_ids = {}
runtime_requests = collections.Counter()
for actor in ['P01', 'P02', 'P03']:
    for day in range(1, 8):
        spec = world['sessions'][actor][str(day)]
        es = [e for e in events if e.get('actor') == actor and e.get('day') == day]
        closed = [e for e in es if e['kind'] in ('session_ended', 'no_use')]
        assert len(closed) == 1, (actor, day, 'not one closed status')
        end = closed[0]
        opened = [e for e in es if e['kind'] == 'session_opened']
        actual_actions = [e for e in es if e['kind'] == 'action']
        obs = [e for e in es if e['kind'] == 'observation']
        result = {'actor': actor, 'day': day, 'date': end['date'], 'status': end['status'], 'reason': end.get('reason'), 'available': spec['available'], 'opened': len(opened), 'actions': len(actual_actions), 'budget': spec['budget'], 'observations': len(obs), 'outcome_statement': end['outcome'], 'participant_memory_chars': len(end.get('memory', ''))}
        assert len(actual_actions) == end['actions'] <= spec['budget']
        assert end['date'] == (dt.date(2026, 11, 15) + dt.timedelta(days=day)).isoformat()
        if end['kind'] == 'no_use':
            assert not opened and not obs and not actual_actions
            assert end['reason'] == ('actor_choice' if spec['available'] else 'unavailable')
        else:
            assert len(opened) == 1
            state_path = relative(end['state']['path'])
            s = read(state_path)[KEY]
            assert s['lastProcessed'] == end['date']
            reward = {'coins': sum(x['coins'] for x in s['ledger']), 'xp': sum(x['xp'] for x in s['ledger'])}
            assert reward['coins'] == end['state']['coins'] and reward['xp'] == end['state']['xp']
            result.update({'first_observation_id': obs[0]['observation_id'], 'last_observation_id': obs[-1]['observation_id'], 'observer_state': state_path, 'trace': relative(end['trace']), 'retained_minutes': sum(x['minutes'] for x in s['timeLog']), 'facts': len(s['facts']), 'ledger_entries': len(s['ledger']), 'rewards': reward, 'trace_interrupted': end['trace_interrupted'], 'reconciled_actions': end['reconciled_actions']})
            snapshots.append({'actor': actor, 'day': day, 'state_path': state_path, 'timeLog': s['timeLog'], 'facts': s['facts'], 'ledger': s['ledger'], 'misses': s['misses'], 'tasks': s['tasks'], 'habits': s['habits'], 'cal': s['cal'], 'flex': s['flex']})
            with zipfile.ZipFile(RUN / result['trace']) as z:
                te = [json.loads(x) for x in z.read('trace.trace').decode().splitlines()]
                opts = te[0]
                before = [x for x in te if x.get('type') == 'before']
                clock = next(x for x in before if x['method'] == 'clockInstall')
                goto = next(x for x in before if x['method'] == 'goto')
                assert clock['startTime'] < goto['startTime']
                installed = dt.datetime.fromtimestamp(clock['params']['timeNumber']/1000, tz=dt.timezone.utc).astimezone(ZoneInfo('Europe/Moscow'))
                assert installed.date().isoformat() == end['date'] and installed.hour == spec['hour']
                assert opts['options'].get('offline', False) == (spec['network'] == 'offline')
                trace_meta.append({'actor': actor, 'day': day, 'trace': result['trace'], 'profile': 'profiles/' + pathlib.Path(opts['options']['userDataDir']).name, 'context_id': opts['contextId'], 'offline': opts['options'].get('offline', False), 'clock_before_navigation': True, 'installed_virtual_time': installed.isoformat(), 'playwright_version': opts['playwrightVersion']})
                errors = [x for x in te if x.get('type') == 'after' and x.get('error')]
                trace_errors.extend({'actor': actor, 'day': day, 'callId': x.get('callId'), 'error': x['error']} for x in errors)
                for line in z.read('trace.network').decode().splitlines():
                    n = json.loads(line)['snapshot']
                    url = n['request']['url']
                    status = n['response']['status']
                    runtime_requests[(urlsplit(url).netloc, status)] += 1
                    path = urlsplit(url).path.lstrip('/')
                    if path == 'personal-lab/': path += 'index.html'
                    body_id = n['response']['content'].get('_sha1')
                    if path in manifest['files'] and body_id and 'resources/' + body_id in z.namelist():
                        runtime_hashes[path].add(sha(z.read('resources/' + body_id)))
        days.append(result)
    final = read(actor + '/day-07/observer-state.json')[KEY]
    all_ids[actor] = {x['id'] for k in ['tasks', 'habits', 'cal', 'facts', 'ledger', 'timeLog'] for x in final[k]}

runtime_mismatches = {p: sorted(h) for p,h in runtime_hashes.items() if h != {manifest['files'][p]['sha256']}}
profiles = {a: sorted({x['profile'] for x in trace_meta if x['actor'] == a}) for a in all_ids}
overlaps = {a + '/' + b: sorted(all_ids[a] & all_ids[b]) for a,b in [('P01','P02'),('P01','P03'),('P02','P03')]}
durations = [e['duration_ms'] for e in actions]
start_time = dt.datetime.fromisoformat(events[0]['real_time_utc'])
end_time = dt.datetime.fromisoformat(events[-1]['real_time_utc'])
package_mismatches = []
with zipfile.ZipFile(RUN / 'source-kit.zip') as z:
    for name, meta in manifest['files'].items():
        entry = 'LifeGame-LAB-014-Pilot/public/' + name
        if entry not in z.namelist() or sha(z.read(entry)) != meta['sha256']:
            package_mismatches.append(name)

semantic_checks = []
expected_time = {
    'P01': [('2026-11-16',10),('2026-11-17',5),('2026-11-19',8),('2026-11-20',10),('2026-11-22',12)],
    'P02': [('2026-11-17',40),('2026-11-19',20),('2026-11-20',60)],
    'P03': [('2026-11-16',3),('2026-11-19',6),('2026-11-21',4)],
}
for actor in expected_time:
    s = read(actor + '/day-07/observer-state.json')[KEY]
    actual = [(x['date'],x['minutes']) for x in s['timeLog']]
    prior_ids = {k:{} for k in ['facts','ledger','timeLog']}
    unchanged = True
    for sn in [x for x in snapshots if x['actor']==actor]:
        for key in prior_ids:
            current = {x['id']:x for x in sn[key]}
            unchanged = unchanged and all(current.get(i)==v for i,v in prior_ids[key].items())
            prior_ids[key] = current
    ledger_ids = {x['id'] for x in s['ledger']}
    fact_ledger_links = all(x.get('ledger') in ledger_ids for x in s['facts'] if x.get('ledger'))
    semantic_checks.append({'actor':actor,'check':'minutes by date','expected':expected_time[actor],'actual':actual,'passed':actual==expected_time[actor]})
    semantic_checks.append({'actor':actor,'check':'prior facts, ledger, timeLog unchanged across all captured states','passed':unchanged})
    semantic_checks.append({'actor':actor,'check':'fact ledger links resolve','passed':fact_ledger_links})
s2 = read('P02/day-07/observer-state.json')[KEY]
semantic_checks.extend([
    {'actor':'P02','check':'meeting exception retains original identity and effective date/time','passed':s2['cal'][0]['exceptions']=={'2026-11-19':{'date':'2026-11-20','time':'15:00'}}},
    {'actor':'P02','check':'all three one-off task dates remain null (deadline only in title)','passed':all(x['sched']['date'] is None for x in s2['tasks'])},
    {'actor':'P02','check':'invoice stored on 25 November without time','passed':s2['cal'][1]['date']=='2026-11-25' and s2['cal'][1]['time']==''},
])
s3=read('P03/day-07/observer-state.json')[KEY]
semantic_checks.append({'actor':'P03','check':'original drawing facts retain cycles 0 and 1 on 16 and 21 November','passed':[(f['date'],f['cycle']) for f in s3['facts'] if f['ref']==s3['tasks'][0]['id']]==[('2026-11-16',0),('2026-11-21',1)]})
assert all(x['passed'] for x in semantic_checks)

audit = {
    'status': 'completed',
    'task': 'LAB-015',
    'analysis_identity': {'context_id': '/root/lab015_independent_analyst', 'fork_turns': 'none', 'independence': 'Independent context; no participant decisions, parent history, old results, expected defects, acceptance or repository documentation read. Only analyst contract, METHOD, REPORT-TEMPLATE and this run artifacts read. Shared filesystem separation is instructional, not ACL enforced.', 'exact_model_id': 'unknown', 'model_family_diversity_established': False},
    'source_commit': source['app_source_commit'],
    'application_variant': read('run.json')['application_variant'],
    'integrity': {'sealed_files_checked': len(seal['files']), 'sealed_mismatches': seal_errors, 'source_kit_sha256': sha((RUN/'source-kit.zip').read_bytes()), 'source_kit_matches_provenance': sha((RUN/'source-kit.zip').read_bytes()) == source['source_kit_sha256'], 'manifest_package_files_checked': len(manifest['files']), 'package_mismatches': package_mismatches, 'runtime_body_hashes_checked': {p:sorted(h) for p,h in sorted(runtime_hashes.items())}, 'runtime_mismatches': runtime_mismatches, 'runtime_body_hash_not_captured_for': sorted(set(manifest['files'])-set(runtime_hashes))},
    'completeness': {'planned':21, 'opened':sum(x['opened'] for x in days), 'completed':sum(x['status']=='completed' for x in days), 'no_use_by_reason':dict(collections.Counter(x['reason'] for x in days if x['status']=='no_use')), 'active':0, 'unrun':0, 'all_dates_closed':len(days)==21, 'observations':len(observations), 'traces':len(trace_meta), 'observer_states':len(snapshots), 'primary_schema_validation':{'source':'FACTS.json', 'valid':facts['all_captured_states_valid'], 'states':len(facts['schema_validation']), 'independent_schema_validator_rerun':False}, 'finish_event_present':events[-1]['kind']=='run_finished'},
    'event_integrity': {'events':len(events), 'kinds':dict(collections.Counter(e['kind'] for e in events)), 'sequence_contiguous': [e['sequence'] for e in events] == list(range(1,len(events)+1)), 'real_times_nondecreasing': all(a['real_time_utc']<=b['real_time_utc'] for a,b in zip(events,events[1:])), 'actions':len(actions), 'action_pairs_checked':len(starts), 'action_errors':action_errors, 'trace_api_errors':trace_errors, 'pending_or_reconcile_required':any(v['pending_action'] or v['reconcile_required'] for v in summary['actors'].values()), 'memory_cap':600, 'maximum_saved_memory_chars':max(x['participant_memory_chars'] for x in days)},
    'isolation': {'profile_paths_from_traces':profiles, 'unique_profile_per_actor':len({p for ps in profiles.values() for p in ps})==3, 'cross_actor_created_id_overlaps':overlaps, 'namespace_keys_per_final_state': {a:list(read(a+'/day-07/observer-state.json')) for a in all_ids}, 'model_contexts_from_runner_provenance':provenance['participants'], 'independent_participant_contexts': 'Supported by recorded fork_turns=none and distinct context IDs, not a security isolation proof.', 'no_observed_cross_actor_entities':all(not x for x in overlaps.values())},
    'days':days,
    'semantic_checks':semantic_checks,
    'state_semantics':snapshots,
    'resolved_action_chain':resolved_actions,
    'browser_trace_checks':trace_meta,
    'network_summary':[{'host':h,'status':s,'requests':n} for (h,s),n in sorted(runtime_requests.items())],
    'costs': {'actions':len(actions), 'planned_action_ceiling':sum(x['budget'] for a in world['sessions'].values() for x in a.values()), 'by_actor':{a:sum(x['actions'] for x in days if x['actor']==a) for a in all_ids}, 'action_types':dict(collections.Counter(e['command'].get('action',e['command']['op']) for e in actions)), 'budget_exhaustions':sum(x['budget']>0 and x['actions']>=x['budget'] for x in days), 'observations':len(observations), 'sealed_files':len(seal['files']), 'sealed_bytes':sum(x['bytes'] for x in seal['files'].values()), 'transport_action_duration_ms':{'sum':round(sum(durations),1),'median':round(statistics.median(durations),1),'maximum':max(durations)}, 'run_wall_seconds':(end_time-start_time).total_seconds(), 'first_event_utc':events[0]['real_time_utc'],'last_event_utc':events[-1]['real_time_utc'], 'model_tokens':None,'model_price':None,'paid_api_calls_reported':0,'human_relay_minutes_reported':0,'human_relay_source':'execution-provenance.json; not independently timed'},
    'semantic_conclusions': [
        {'actor':'P01','minutes_expected_and_retained':[10,5,8,10,12], 'total_minutes':45,'completion_dates':['2026-11-16','2026-11-20','2026-11-22'],'habit_completion_facts':3,'supporting_zero_reward_habitStep_facts':3,'ledger_entries':3,'coins':15,'xp':15,'partial_efforts_preserved_without_completion':True,'miss_dates':['2026-11-17','2026-11-18','2026-11-19','2026-11-21'],'interpretation':'5 and 8 minute efforts are retained in timeLog; incomplete marks create later misses, without coin/XP debit in captured ledger. Basic weekly count of 3 is accurate for marks, not a weekly effort total. Title mentions ten minutes; stored dailyTarget is one approach, not ten minutes.'},
        {'actor':'P02','minutes_expected_and_retained':[40,20,60],'total_minutes':120,'completion_facts':4,'coins':35,'xp':35,'meeting_original':{'date':'2026-11-19','time':'14:00'},'meeting_effective_exception':{'date':'2026-11-20','time':'15:00'},'meeting_completion':{'occurrence':'2026-11-19','scheduledDate':'2026-11-20','scheduledTime':'15:00','date':'2026-11-20'},'invoice_date':'2026-11-25','invoice_time':'','deadline_representation':'20 November 20:00 appears only in task title; sched.date null, no structured deadline saved. This follows the explicit workaround, not a failed save.','hour_allocation':'Final 60 minutes assigned to send task by participant; no exact 18:30 sending timestamp or file stored. Fact timestamp is recording around 19:00, not evidence of actual sending time.','offline':'day-06 context offline true, clock installed before navigation; trace records net::ERR_INTERNET_DISCONNECTED plus cached 200 responses and usable UI/search. Existing cache, not cold-offline installation or device delivery.'},
        {'actor':'P03','minutes_expected_and_retained':[3,6,4],'total_minutes':13,'completion_facts':3,'coins':30,'xp':30,'first_task_cycles':[0,1],'weekly_schedule':{'type':'weekly','days':[6]},'separate_task_on_day4':True,'misses':0,'interpretation':'Session marks are not proof of a seven-minute norm. Changing first one-off task to Saturdays retains cycle-0 fact on 16 November and adds cycle-1 fact on 21 November. Future Saturday not observed.'}
    ],
    'transport_and_method_limits': ['No errors/dialog dismissals/reconciliation events in events.jsonl; native-dialog rejection, file upload and tab control remain transport limitations, not product findings.', 'Recommended CLI output budget is 2600 tokens; full observation JSON persisted. Participant-facing terminal transcript is not in these artifacts, so no specific CLI truncation is established.', 'DOM may show labels off viewport; PNG reflects captured viewport. Mobile Full edit is scrollable. Action duration is transport latency, not human task time.', 'Exact model IDs, settings, token use and price not exposed; distinct inherited contexts do not establish model-family diversity.', 'AI persona choices and accelerated dates do not establish human retention, fatigue frequency or Safari/iPhone behavior.'],
}
(RUN / 'SEMANTIC-AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:audit[k] for k in ['integrity','completeness','event_integrity','costs']},ensure_ascii=False,indent=2))
