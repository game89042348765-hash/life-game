"""Assemble portable selected evidence and independent LAB-015 reports."""
import collections
import datetime as dt
import hashlib
import json
import pathlib
import shutil
import zipfile

RUN = pathlib.Path(__file__).resolve().parent.parent
EVIDENCE = RUN / 'evidence'
EVIDENCE.mkdir(exist_ok=True)
ENTRIES = []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def load(path):
    return json.loads(path.read_text())


seal = load(RUN/'ORIGINAL-EVIDENCE-MANIFEST.json')['files']


def copy(source, dest=None, oid=None):
    src = RUN/source
    dst = EVIDENCE/(dest or src.name)
    shutil.copyfile(src,dst)
    assert digest(src)==digest(dst)
    ENTRIES.append({'path':'evidence/'+dst.name,'sha256':digest(dst),'bytes':dst.stat().st_size,'kind':'byte_identical_copy','source_path':source,'source_sha256':digest(src),'source_sealed':source in seal,'observation_id':oid})
    return 'evidence/'+dst.name


def derived(name, data, sources, description):
    dst=EVIDENCE/name
    write(dst,data)
    ENTRIES.append({'path':'evidence/'+name,'sha256':digest(dst),'bytes':dst.stat().st_size,'kind':'derived_json_extract','description':description,'sources':[{'path':s,'sha256':digest(RUN/s),'sealed':s in seal} for s in sources]})


selected = [
    'P01/day-02/P01-d02-o0015','P01/day-04/P01-d04-o0019','P01/day-05/P01-d05-o0027','P01/day-05/P01-d05-o0028','P01/day-07/P01-d07-o0033',
    'P02/day-01/P02-d01-o0013','P02/day-01/P02-d01-o0020','P02/day-04/P02-d04-o0026','P02/day-04/P02-d04-o0035','P02/day-04/P02-d04-o0037','P02/day-05/P02-d05-o0044','P02/day-06/P02-d06-o0045','P02/day-06/P02-d06-o0049','P02/day-07/P02-d07-o0057',
    'P03/day-04/P03-d04-o0015','P03/day-06/P03-d06-o0031','P03/day-06/P03-d06-o0033','P03/day-06/P03-d06-o0039','P03/day-07/P03-d07-o0040',
]
for stem in selected:
    for suffix in ['.png','.json']:
        copy(stem+suffix,oid=pathlib.Path(stem).name)
for actor in ['P01','P02','P03']:
    copy(actor+'/day-07/observer-state.json',actor+'-final-observer-state.json')
for name in ['experiment-source.json','source-manifest.json','execution-provenance.json','world.json','FACTS.json','ORIGINAL-EVIDENCE-MANIFEST.json','SEMANTIC-AUDIT.json']:
    copy(name)

new_selected = {
    'R1':['day1-five-minutes','day2-thirteen-retained'],
    'R2':['one-off-form','deadline-title-only'],
    'R3':['day1-completion-settled','completed-not-in-today','past-fact-found','recurrence-form-top','recurrence-form-bottom','weekly-result-persisted'],
}
for case,suffixes in new_selected.items():
    for suffix in suffixes:
        oid=case+'-'+suffix
        for ext in ['.png','.json']:
            copy('reproductions/'+case+'/'+oid+ext,oid=oid)

events=[json.loads(x) for x in (RUN/'events.jsonl').read_text().splitlines()]
derived('event-chain.json',{'source':'events.jsonl','events':[e for e in events if e['kind'] in ['session_opened','session_ended','no_use','action_started','action','run_started','run_finished']]},['events.jsonl'],'Exact original event objects; observation pointer events omitted. Commands, intention, results and participant closing statements retained.')
derived('participant-statements.json',{'statements':[{'actor':a,'source':a+'/FINAL.md','statement':(RUN/a/'FINAL.md').read_text()} for a in ['P01','P02','P03']]},['P01/FINAL.md','P02/FINAL.md','P03/FINAL.md'],'Participant words transcribed without editorial changes into JSON; not analyst or application claims.')

with zipfile.ZipFile(RUN/'P02/day-06/trace.zip') as z:
    trace=[json.loads(x) for x in z.read('trace.trace').decode().splitlines()]
    network=[json.loads(x) for x in z.read('trace.network').decode().splitlines()]
    selected_trace=[e for e in trace if e.get('type')=='context-options' or (e.get('type')=='before' and e.get('method') in ['clockInstall','goto'])]
    callids={e['callId'] for e in selected_trace if 'callId' in e}
    selected_trace += [e for e in trace if e.get('type')=='after' and e.get('callId') in callids]
    selected_network=[e for e in network if e['snapshot']['request']['url'].endswith('/personal-lab/') or e['snapshot']['request']['url'].endswith('/flex-ui.js')]
derived('offline-trace-extract.json',{'trace_entry':'trace.trace','trace_events':selected_trace,'network_entry':'trace.network','network_events':selected_network,'note':'Actual trace excerpts; not a newly generated browser trace.'},['P02/day-06/trace.zip'],'Offline context and clock-before-navigation plus disconnected fetch and cached responses from actual participant trace.')

audit=load(RUN/'SEMANTIC-AUDIT.json')
results=load(RUN/'reproductions/results.json')
attempts=load(RUN/'reproductions/ATTEMPTS.json')
all_attempt_dirs=[p.parent for p in (RUN/'reproductions').rglob('actions.json')]
repro={
    'status':'completed','scenario_count':3,'reproduced':3,'technical_bugs_confirmed':0,
    'application_source_commit':audit['source_commit'],
    'scope':'Three substantial UX/product suspicions, not three proven technical defects.',
    'rules':{'fresh_context_per_attempt':True,'participant_profiles_used':False,'state_writes':'ordinary UI only','evaluate':'read-only DOM/state observer','external_requests':'all except configured server origin blocked','service_workers':'blocked in reproductions; primary cached offline entry not repeated','clock':'installed before navigation; completion settled before moving date in final R3'},
    'cases':results,'attempt_history':attempts,
    'attempt_context_count':len(all_attempt_dirs),
    'untraced_initial_read_only_ui_probe_contexts':1,
    'attempted_ui_operations_in_all_recorded_attempts':sum(len(load(p/'actions.json')) for p in all_attempt_dirs),
    'recorded_attempts':[{'directory':str(p.relative_to(RUN)),'status':load(p/'result.json')['status'],'trace':str((p/'trace.zip').relative_to(RUN)),'trace_sha256':digest(p/'trace.zip'),'trace_bytes':(p/'trace.zip').stat().st_size} for p in sorted(all_attempt_dirs)],
    'instructions':'reproductions/README.md','script':'reproductions/reproduce.py','script_sha256':digest(RUN/'reproductions/reproduce.py'),
    'script_portability':'--url and --output-dir; default creates a fresh timestamped directory. Refuses to overwrite case evidence.',
    'code_changed_after_recorded_runs':'Only endpoint/output argument handling, overwrite guard and explicit settling of form/clock transitions were improved. R1 was rerun with settled captures; final R2/R3 traces retained without repeating their successful UI scenarios.',
    'limits':['The two initial minute-label selector timeouts are automation failures.','R3 attempt 2 advanced virtual time before completion settled; excluded from product conclusions.','R1 attempt 2 passed semantic assertions but PNG caught closing modal; final R1 capture is settled.','No extra defect, human-frequency estimate or retention result is inferred from the attempt errors.'],
}
write(RUN/'REPRODUCTION-RESULTS.json',repro)
copy('REPRODUCTION-RESULTS.json')


def ev(oid,ext='png'):
    return {'observation_id':oid,'path':'evidence/'+oid+'.'+ext}


def state(actor,oid):
    return {'observation_id':oid,'path':'evidence/'+actor+'-final-observer-state.json'}


def reproduction(case,status,steps,oids):
    return {'status':status,'case_id':case,'steps':steps,'evidence':[ev(o) for o in oids]+[ev(o,'json') for o in oids]}


findings=[
    {
        'id':'F-001','category':'observed_ux_friction','title':'В недельном обзоре Базового не удалось увидеть короткие чтения по минутам',
        'actor':'P01','day':5,'intent':'Увидеть прошлые вечера, включая 5 и 8 минут, и результат недели.',
        'expected':'Найти видимый след частичного усилия за прошлые даты.',
        'observed':'После включения статистики участница увидела только 2 отметки. Прокрутка не открыла прошлые минуты; поиск остановлен. День 7 показал 3 отметки. Все 45 введённых минут сохранены; это не потеря данных и не арифметическая ошибка счётчика отметок.',
        'evidence':[ev('P01-d05-o0027'),ev('P01-d05-o0027','json'),ev('P01-d05-o0028'),ev('P01-d07-o0033'),state('P01','P01-d07-o0033')],
        'reproduction':reproduction('R1','reproduced',['Свежий context 390×844, Базовый со статистикой.','Создать ежедневное чтение, записать 5 минут 16 ноября без выполнения.','17 ноября записать 8 минут без выполнения.','Сверить PNG: текущие 8 минут, 0 недельных отметок; observer timeLog сохраняет 5+8 минут.'],['R1-day2-thirteen-retained']),
        'severity':'medium','severity_reason':'Не закрыта цель заметить небольшое прошлое усилие; поиск прекращён. Данные доступны для восстановления и запись текущего результата успешна.',
        'confidence':'high','confidence_reason':'Заявление и end.frictions согласованы с PNG/JSON двух дат и конечным timeLog; свежий UI подтвердил ограничение этого экрана. Наличие истории в других разделах не опровергается.',
        'suggested_next_step':'Проверить короткий недельный обзор дат и минут, который показывает частичное усилие отдельно от отметок.'
    },
    {
        'id':'F-002','category':'product_limit','title':'Простое разовое задание сохраняет срок только в названии',
        'actor':'P02','day':1,'intent':'Запланировать отправку проекта до пятницы 20 ноября, 20:00.',
        'expected':'Явно задать срок или понять способ поставить дату обязательства.',
        'observed':'В форме разового задания участник не увидел срока и вписал его в название. В сохранённом задании sched.date=null; время 20:00 — только текст. Календарные даты поддерживаются отдельным типом и перенос встречи позднее удался.',
        'evidence':[ev('P02-d01-o0013'),ev('P02-d01-o0013','json'),ev('P02-d01-o0020'),state('P02','P02-d07-o0057')],
        'reproduction':reproduction('R2','reproduced',['Свежий context, Базовый с календарём.','Открыть Добавить в ритм, оставить Разовое задание и вписать срок в название.','В форме нет поля даты; сохранить, перезагрузить.','В state сохранены название и разовое расписание с date=null, календарное событие не создано.'],['R2-one-off-form','R2-deadline-title-only']),
        'severity':'medium','severity_reason':'Основной срок проекта не стал структурным обязательством. Текстовый обход сохранил намерение, а ущерба от опоздания в опыте нет.',
        'confidence':'high','confidence_reason':'Реальная форма и явный обход участника подтверждены PNG, командой fill и сохранённым состоянием; на свежих данных тот же результат.',
        'suggested_next_step':'Проверить понятный выбор между сроком задания и событием календаря в коротком добавлении.'
    },
    {
        'id':'F-003','category':'observed_ux_friction','title':'Перенос встречи и поиск завершённого потребовали выхода в Полный',
        'actor':'P02','day':4,'intent':'Перенести встречу на 20 ноября 15:00; позднее найти вчерашнюю отправку проекта.',
        'expected':'Понятный вход к переносу и сохранённой истории из краткого обзора.',
        'observed':'В Базовом у встречи участник увидел только отметку выполнения. Перешёл в Полный и успешно перенёс её. На день 6 завершённые дела отсутствовали в кратком обзоре; отправку нашёл через Полный → Поиск. Отсутствие дел на сегодня соответствует их завершению, потеря истории не установлена.',
        'evidence':[ev('P02-d04-o0026'),ev('P02-d04-o0035'),ev('P02-d04-o0037'),ev('P02-d06-o0045'),ev('P02-d06-o0049'),state('P02','P02-d07-o0057')],
        'reproduction':{'status':'not_attempted','steps':[],'evidence':[],'reason':'Точный маршрут переноса встречи не повторялся: исходный UI и конечное исключение подтверждают успех. R3 независимо подтверждает маршрут поиска завершённого задания, без обобщения на перенос календаря.'},
        'severity':'low','severity_reason':'Затрачена дополнительная навигация, обе цели достигнуты; встреча и история сохранились, бюджет не исчерпан.',
        'confidence':'high','confidence_reason':'Два конкретных frictions, before/after UI и сохранённое исключение встречи/факт отправки согласованы. Вывод относится к затруднению данного участника, не отсутствию функций.',
        'suggested_next_step':'Проверить заметные входы к действиям записи и недавней истории из Базового.'
    },
    {
        'id':'F-004','category':'observed_ux_friction','title':'Новое рисование участница оформила отдельным разовым заданием',
        'actor':'P03','day':4,'intent':'Сохранить сегодняшние 6 минут рядом с прежним рисованием без ежедневного обязательства.',
        'expected':'Понять, как продолжить прежнее действие в новый день.',
        'observed':'В Настроить нашла прежнее задание с флажком и подписью разово, но не разобралась с добавлением результата. Отменила настройку и создала Рисование 19 ноября. Его 6 минут и выполнение сохранены; 21 ноября смогла изменить первое задание на субботы через Полный.',
        'evidence':[ev('P03-d04-o0015'),ev('P03-d04-o0015','json'),ev('P03-d06-o0039'),state('P03','P03-d07-o0040')],
        'reproduction':{'status':'not_attempted','steps':[],'evidence':[],'reason':'Это наблюдённая непонятность, не гипотеза отсутствия кода. R3 показывает работающий путь изменения повторяемости, но не воспроизводит понимание участницы.'},
        'severity':'low','severity_reason':'Усилие сохранилось в дополнительном задании; возникло разделение одной деятельности на записи, без потери данных.',
        'confidence':'high','confidence_reason':'Эпизод прямо записан в end.frictions и FINAL; PNG показывает контекст выбора, state подтверждает отдельное задание и результат.',
        'suggested_next_step':'Проверить понятность разового действия и повторения при повторном возвращении к той же деятельности.'
    },
    {
        'id':'F-005','category':'observed_ux_friction','title':'Изменение повторяемости на телефоне ведёт через длинную форму',
        'actor':'P03','day':6,'intent':'Продолжать рисование раз в неделю по субботам вместо ежедневной нагрузки.',
        'expected':'Изменить только повторяемость и быстро сохранить.',
        'observed':'Через Полный → Поиск → действие → Изменить / перенести открылась форма с блоком, этапом, целью, темпом, наградой и другими полями. Для сохранения участница прокрутила 500 и затем 200 px. Настройка и 4 минуты с новым выполнением сохранены.',
        'evidence':[ev('P03-d06-o0031'),ev('P03-d06-o0033'),ev('P03-d06-o0039'),state('P03','P03-d07-o0040')],
        'reproduction':reproduction('R3','reproduced',['Свежий context 375×844: создать разовый скетч, записать 3 минуты и дождаться сохранённой отметки 16 ноября.','21 ноября открыть Полный → Поиск → скетч → Изменить / перенести.','Выбрать Раз в неделю и Сб. Кнопка Сохранить ниже текущего viewport; прокрутить форму.','Сохранить, вернуться в Базовый, записать 4 минуты и отметить. Перезагрузка сохраняет оба факта циклов 0/1 и 7 минут.'],['R3-recurrence-form-top','R3-recurrence-form-bottom','R3-weekly-result-persisted']),
        'severity':'medium','severity_reason':'Участница сообщила об утомлении и намерении избегать Полного. Простая настройка затрагивает много полей, но остаётся выполнимой и восстановимой.',
        'confidence':'high','confidence_reason':'Слова участницы, два scroll-действия, PNG формы и сохранённое расписание подтверждены; свежий UI даёт тот же длинный маршрут и кнопку ниже viewport. Человеческая частота/retention из этого не следуют.',
        'suggested_next_step':'Проверить короткий редактор расписания с сохранением рядом с изменяемыми полями.'
    },
]
limitations=[
    {'id':'L-001','category':'transport_limit','text':'Native dialogs автоматически отклоняются; file upload и управление вкладками недоступны участнику. В этом run нет зарегистрированного диалога/ошибки/reconcile. Эти функции не оценены.'},
    {'id':'L-002','category':'transport_limit','text':'Рекомендован лимит CLI-вывода 2600 токенов, полные observation JSON сохранены. Терминальные ответы участникам отсутствуют в наборе; конкретная обрезка не доказана.'},
    {'id':'L-003','category':'ai_hypothesis','text':'Желание ролей вернуться и избегать длинных настроек — заявления AI-персон. Влияние на удобство и retention людей остаётся гипотезой, проценты людей не вычисляются.'},
    {'id':'L-004','category':'product_limit','text':'Вариант локальный, без регистрации/backend и синхронизации устройств. Проверен кэшированный офлайн-вход, не первая офлайн-установка и не доставка push при закрытом браузере.'},
    {'id':'L-005','category':'transport_limit','text':'Точные модели, семьи, настройки, токены и цена неизвестны; fork_turns=none подтверждает отдельные контексты по provenance, не разнообразие семейств. Разделение файлов организационное, без ACL.'},
    {'id':'L-006','category':'transport_limit','text':'DOM-assisted Chromium 390/375/1100 px не физический iPhone/Safari. Виртуальная неделя не воспроизводит человеческую усталость; задержки команды не равны времени задачи.'},
    {'id':'L-007','category':'product_limit','text':'Награды записаны по принятым отметкам, а не автоматически проверенному достижению 10/7 минут. Наступление следующей субботы, напоминания, общий итог времени во всех разделах, архивирование, экспорт/импорт и отмена не покрыты.'},
]
write(RUN/'FINDINGS.json',{'status':'completed','source_commit':audit['source_commit'],'application_variant':audit['application_variant'],'technical_bugs_confirmed':0,'findings':findings,'limitations':limitations})

cost=audit['costs']
report=f'''# LAB-015 — независимый анализ реального AI-пилота

Статус: **completed**. Все 21 персона-дата учтены; 16 входов закрыты. Сохранение фактических минут, выполнений, переноса встречи и наград согласуется с решениями участников. **Существенных технических дефектов не установлено.** Подтверждены четыре наблюдённых UX-затруднения и одна граница простого добавления; три существенных подозрения проверены через настоящий UI на свежих данных. Невыполненные цели обзора остаются перечислены ниже: completed означает завершённый опыт, а не успех каждой цели.

## 1. Источник, независимость и доказательства

Вариант — `{audit['application_variant']}`, исходник `{audit['source_commit']}`. [Происхождение](evidence/experiment-source.json), [манифест приложения](evidence/source-manifest.json), [модельный provenance](evidence/execution-provenance.json). Git HEAD репозитория в происхождении отличается от коммита приложения; источником выводов служит замороженный пакет выбранного варианта.

SHA-256 исходного `source-kit.zip`: `{audit['integrity']['source_kit_sha256']}`. Все 27 файлов пакета совпали с source-manifest. В настоящих traces совпали захваченные тела 26 runtime-файлов, включая app.js, flex-model.js и flex-ui.js; тело sw.js отдельно в trace не сохранено. Все **301 запечатанный первичный файл** совпали по размеру и SHA-256. [Исходная печать](evidence/ORIGINAL-EVIDENCE-MANIFEST.json) и [самостоятельная сверка](evidence/SEMANTIC-AUDIT.json) сохранены. Код приложения и первичный опыт не менялись.

Аналитик — отдельный чистый контекст `/root/lab015_independent_analyst`, fork_turns=none, без решений участников и истории координатора. Прочитаны PROMPT-ANALYST, METHOD и REPORT-TEMPLATE из пакета и только артефакты этого run. Старые результаты, ожидаемые дефекты, ручная приёмка и документы репозитория не читались; код приложения для причинных догадок не понадобился. Три участника имеют разные context IDs с fork_turns=none и собственные persistent Chromium profiles по provenance и traces. Созданные task/habit/cal/fact/ledger/timeLog IDs между персонами не пересекаются. Разделение доступа организационное, а не доказанная ACL-изоляция.

Точные model IDs, семейства, настройки, токены и цена не раскрыты. Настройки унаследованы; разнообразие семейств не установлено. Самостоятельность участников подтверждается записью процесса, а не независимой проверкой внутреннего runtime модели.

Все ссылки отчёта относительные. [MANIFEST доказательств](evidence/MANIFEST.json) указывает SHA-256 и происхождение выбранных копий. PNG/observation JSON приложения, [слова участников](evidence/participant-statements.json), [команды и закрытия сессий](evidence/event-chain.json), состояния наблюдателя и интерпретация аналитика разделены.

## 2. Полнота и непрерывность

| Персона | Входы / completed | no_use unavailable | no_use actor_choice | Действия |
| --- | ---: | --- | --- | ---: |
| P01 | 5 / 5 | 18 ноября, день 3 | 21 ноября, день 6 | 28 |
| P02 | 6 / 6 | 18 ноября, день 3 | — | 51 |
| P03 | 5 / 5 | 17 и 20 ноября, дни 2 и 5 | — | 35 |
| Всего | 16 / 16 | 4 даты | 1 дата | 114 |

Active=0, unrun=0, блокировок и исчерпания бюджета нет. На no_use нет открытия UI, действий или наблюдений. В дни P03-3 и P03-7 состоялся реальный вход с одним наблюдением и нулём действий; это не пропуски. [Предзаданный мир](evidence/world.json) остаётся исходным сценарием со статусом planned_not_executed; фактическое завершение подтверждают журнал, summary и run_finished.

Есть 130 PNG/JSON наблюдений, 16 настоящих traces и 16 observer-state. Последовательность 397 событий непрерывна, реальные времена не убывают; все 114 action_started сопоставлены успешным action, существующим before/after PNG и элементу до действия. Неизвестных результатов, повторных автоматических действий, ошибок trace API, interruptions и reconcile нет. В каждом trace часы установлены **до навигации**, дата/час и online/offline совпали с миром. Сохранённая память максимум 353 из 600 символов. FACTS сообщает валидность всех 16 схем; аналитик отдельно проверил семантику и неизменность старых записей, но не выдаёт повторный запуск того же schema validator за самостоятельное доказательство.

Незакрытые цели: P01 в дни 5 и 7 не получила желаемый обзор прошлых коротких чтений; P02 в день 1 сохранил срок отправки только текстом; P03 в день 4 не нашла понятного продолжения прежнего разового действия и создала отдельное. Эти цели не превращены в blocked/unrun, потому что сессии действительно закрыты, а обходы и отказ от поиска записаны.

## 3. Намерения и долговечный результат

| Персона и маршрут | Что реально получилось | Сверка хранения |
| --- | --- | --- |
| P01: спокойное вечернее чтение | Дни 1/2/4/5/7: 10/5/8/10/12 минут. Только дни 1/5/7 отмечены выполненными. [5 минут: P01-d02-o0015](evidence/P01-d02-o0015.png), [8 минут: P01-d04-o0019](evidence/P01-d04-o0019.png), [итог: P01-d07-o0033](evidence/P01-d07-o0033.png). | [Конечный state P01](evidence/P01-final-observer-state.json): 5 timeLog записей = **45 минут**, 3 habit-факта плюс 3 служебных habitStep с нулевой наградой, 3 ledger по 5 = **15 монет / 15 XP**. Частичные 5 и 8 минут не потеряны. |
| P02: проект, встреча, счёт | Созданы три задания и встреча. 17 ноября материалы: 40 минут и выполнение; 19 ноября незавершённый черновик: 20 минут. Перенос на 20 ноября 15:00 виден в [P02-d04-o0035](evidence/P02-d04-o0035.png) и [P02-d04-o0037](evidence/P02-d04-o0037.png). 20 ноября отмечены черновик, встреча и отправка, ещё 60 минут записаны к отправке: [P02-d05-o0044](evidence/P02-d05-o0044.png). | [Конечный state P02](evidence/P02-final-observer-state.json): **120 минут**, 4 факта/ledger = **35 монет / 35 XP**. У встречи база 19 ноября 14:00 и exception на 20 ноября 15:00; факт корректно хранит исходный occurrence и effective scheduledDate/Time. Счёт — календарное событие **25 ноября без времени**, как выбрал участник: [P02-d07-o0057](evidence/P02-d07-o0057.png). |
| P03: маленькие шаги рисования | 16 ноября разовое действие: 3 минуты и отметка; 19 ноября отдельное действие: 6 минут и отметка. 21 ноября первое действие переведено на субботы, записаны 4 минуты и отметка: [P03-d06-o0039](evidence/P03-d06-o0039.png). После пропусков оставался свободный день; [P03-d07-o0040](evidence/P03-d07-o0040.png). | [Конечный state P03](evidence/P03-final-observer-state.json): **13 минут**, 3 факта/ledger = **30 монет / 30 XP**. Первое действие сохранило факт cycle 0 от 16 ноября и получило cycle 1 от 21 ноября; weekly.days=[6]. Второе разовое действие и его 6 минут остались отдельными. |

Во всех 16 состояниях прежние facts, ledger и timeLog записи сохранялись без изменения. Награда начислена по отдельным отметкам; запись минут сама её не создавала. У P01 дни 17/18/19/21 позже отмечены внутренними misses; в захваченном ledger нет списания монет/XP за них. Это не потеря 5 и 8 минут. Название «10 минут» — текст, хранимый dailyTarget=1 означает подход, а не автоматическую проверку десяти минут. Аналогично три отметки P03 не доказывают достижение семиминутной нормы.

P02 сознательно отнёс финальные 60 минут к отправке; аналитик не перераспределяет их на черновик. Файл и точное время отправки 18:30 даны жизненным brief, но в UI не вводились: timestamp факта около 19:00 — время записи, а не подтверждение отправки. Старые задания остаются status=active с фактами выполнения, без удаления/архива: их отсутствие в сегодняшнем кратком списке не означает исчезновения данных.

Успешные маршруты: короткое добавление и раздельный учёт времени/выполнения, возвращение после no_use, сохранение частичного усилия, перенос календарного occurrence, поиск выполненного, изменение повторяемости с сохранением старых фактов и новое обязательство на 25 ноября. Кэшированный офлайн-вход P02-6 подтверждён [извлечением настоящего trace](evidence/offline-trace-extract.json): offline=true, ошибка сетевого fetch и 200 из кэша, после чего работают [Базовый P02-d06-o0045](evidence/P02-d06-o0045.png) и [история отправки P02-d06-o0049](evidence/P02-d06-o0049.png). Первое посещение было онлайн; это не проверка холодной офлайн-установки.

## 4. Находки и свежие воспроизведения

**F-001 — observed_ux_friction, medium, уверенность high.** P01-5 искала прошлые 5 и 8 минут, включила статистику и увидела только [2 отметки: P01-d05-o0027](evidence/P01-d05-o0027.png). [Прокрутка P01-d05-o0028](evidence/P01-d05-o0028.png) не помогла; поиск остановлен. День 7 снова дал число отметок. Недельный счётчик арифметически верен, но цель видеть короткое усилие осталась. R1 подтвердил на свежем UI: [R1-day2-thirteen-retained](evidence/R1-day2-thirteen-retained.png), [JSON со state](evidence/R1-day2-thirteen-retained.json) — 5+8 минут сохранены, 0 отметок, на экране только текущие 8 минут. Серьёзность связана с незакрытой целью обзора; потеря данных и отсутствие истории во всём продукте не установлены.

**F-002 — product_limit, medium, уверенность high.** P02-1 вписал срок в название: [P02-d01-o0013](evidence/P02-d01-o0013.png). В короткой форме разового задания нет поля даты; в state date=null. R2 повторил [форму R2-one-off-form](evidence/R2-one-off-form.png) и [сохранённый результат R2-deadline-title-only](evidence/R2-deadline-title-only.json). Структурное обязательство не создано; текстовый обход удался, факта опоздания нет. Наличие календарного типа и успешного переноса не позволяют объявить дату отсутствующей во всём приложении.

**F-003 — observed_ux_friction, low, уверенность high.** P02-4 не нашёл перенос у [встречи в Базовом P02-d04-o0026](evidence/P02-d04-o0026.png); P02-6 не нашёл вход в историю из свободного дня. Обе цели достигнуты через Полный, перенос и факт отправки подтверждены UI/state. Это цена навигации при работающих функциях. Точный перенос встречи отдельно не воспроизводился; исходных before/after/state достаточно для вывода об эпизоде, а R3 дополнительно показывает работающий поиск завершённого задания.

**F-004 — observed_ux_friction, low, уверенность high.** P03-4 в [Настроить P03-d04-o0015](evidence/P03-d04-o0015.png) не поняла, как добавить сегодняшний результат к прежнему разовому рисованию. Отменила и создала вторую запись. 6 минут сохранены, ущерб ограничен раздроблением одной деятельности. Само непонимание не воспроизводится как техническая ошибка; отсутствия функции аналитик не утверждает. На день 6 участница нашла работающую смену расписания.

**F-005 — observed_ux_friction, medium, уверенность high.** P03-6 меняла только повторяемость, но прошла форму с блоком, этапом, целью, темпом, наградой и другими полями: [P03-d06-o0031](evidence/P03-d06-o0031.png) → [P03-d06-o0033](evidence/P03-d06-o0033.png). Два scroll-действия и слова об утомлении записаны; всё сохранилось. R3 подтвердил длинную форму и кнопку ниже текущего 375×844 viewport: [R3-recurrence-form-top](evidence/R3-recurrence-form-top.png), [R3-recurrence-form-bottom](evidence/R3-recurrence-form-bottom.png). [R3-weekly-result-persisted.json](evidence/R3-weekly-result-persisted.json) сохраняет оба цикла и 7 минут. Уверенность high относится к этому маршруту и наблюдению, а не к частоте проблемы у людей.

Три сценария R1/R2/R3 выполнены в новых контекстах на иных вымышленных данных, с блокировкой внешних запросов. Изменения только обычными click/fill/select/check/scroll; observer читает state, внутренних функций/записи localStorage нет. Настоящие traces остаются в `reproductions/R1/trace.zip`, `R2/trace.zip`, `R3/trace.zip`; [сводка и хеши](evidence/REPRODUCTION-RESULTS.json). Для переноса есть `reproductions/README.md` и параметры `--url`, `--output-dir` у скрипта; порт исходного опыта не считается универсальным.

Было 7 попыток трёх сценариев и один начальный read-only UI-просмотр. Неуспешные/заменённые попытки сохранены: два selector timeout поля минут, одна преждевременная смена виртуальной даты до завершения обработки клика, один снимок закрывающейся формы. Они относятся к автоматизации аналитика; не включены в findings и не меняют первичный опыт. Финальные R1/R3 дождались нужного UI/state до проверки. Успешные R2/R3 после оформления не запускались повторно.

## 5. Ограничения и непроверенные вопросы

Transport limits: native dialogs автоматически отклоняются; upload файла и управление вкладками участником недоступны. В данном журнале нет случившегося диалога или отказа транспорта, поэтому эти механики продукта не оценены. Рекомендованный лимит вывода CLI — 2600 токенов; полные observations сохранены. Терминальные ответы участникам в артефактах отсутствуют: **конкретная обрезка вывода не доказана**. DOM может давать доступ к элементу вне viewport; PNG показывает фактически захваченный экран, а форма Полного прокручивается. Длительность команды не является временем человеческой задачи.

Product limits: локальные профили без регистрации/backend; синхронизация устройств не проверялась. Офлайн проверен только на ранее кэшированном Chromium. Напоминания включены, но их срабатывание, системное разрешение и push при закрытом браузере не проверены. Нет физического Safari/iPhone. Архивирование, экспорт/импорт, отмена и все возможные разделы истории времени естественными маршрутами не покрыты. Следующая суббота после недельной настройки P03 не наступала.

AI-гипотезы: заявления «вернусь после чтения» и «буду избегать Полного» описывают решения вымышленных ролей. У P01-6 одновременно были усталость, отсутствие чтения и нежелание искать прошлое; причинный вклад интерфейса в пропуск не установлен. Ускоренная неделя и три контекста с унаследованными настройками не доказывают retention, удобство для людей или долю населения. Сравнение с прежними пилотами и причинный A/B-эффект не проводились.

## 6. Следующий план — три пункта, без изменения приложения в этом задании

1. **Проверить обзор частичного усилия** на прототипе недельных дат/минут отдельно от отметок. Основание F-001; ожидаемый результат: человек находит сохранённые 5 и 8 минут и отличает их от полного выполнения без перехода в большую форму. Минуты и ledger при просмотре не меняются.
2. **Проверить короткие действия над записью**: расписание/перенос/недавние выполнения рядом с Базовым списком, сохранив доступ в Полный. Основание F-003–F-005; ожидаемый результат: изменить повторение и найти прошлое выполнение без прохождения нерелевантных полей, с неизменными датами и фактами прежних циклов. Затем проверить наступление следующей субботы.
3. **Проверить постановку обязательства со сроком**: ясный выбор даты задания или календарного события в добавлении. Основание F-002; ожидаемый результат: на просьбу «до 20 ноября 20:00» человек сохраняет проверяемую структурную дату либо явно понимает выбранное текстовое представление. Не трактовать календарное событие как автоматически эквивалентный дедлайн проекта.

## 7. Фактические затраты

Пилот: **114 из потолка 368 операций** — 77 click, 26 fill, 3 select, 4 check, 4 scroll. P01/P02/P03: 28/51/35. Наблюдений 130; первичных запечатанных файлов 301, суммарно **{cost['sealed_bytes']:,} байт** (около {cost['sealed_bytes']/1024/1024:.2f} MiB), включая 130 PNG, 130 observation JSON, 16 traces и 16 states. Отдельно source-kit.zip — 535607 байт; браузерные profiles не входят в размер запечатанных доказательств.

Run wall time: {cost['first_event_utc']} → {cost['last_event_utc']}, **{cost['run_wall_seconds']:.3f} с** (8 мин 55.7 с), включая параллельные участнические контексты и оркестрацию. Сумма измеренных action transport durations **3895.8 мс**, медиана **29.4 мс**, максимум **162.5 мс**; это технические задержки. По provenance платных API-вызовов 0, ручных передач 0 минут; последнее не измерялось независимо. Токены и цена неизвестны, стоимость по аккаунтному лимиту не оценена.

Анализ отдельно: 3 сценария, 7 записанных попыток, {repro['attempted_ui_operations_in_all_recorded_attempts']} попыток UI-операций во всех журналах воспроизведения, включая неуспешные. Настоящие traces и ошибки автоматизации сохранены отдельно от первичного пилота. Время/токены аналитической модели не раскрыты. `SEMANTIC-AUDIT.json`, `FINDINGS.json`, `REPRODUCTION-RESULTS.json` и переносимые копии сформированы {dt.datetime.now(dt.timezone.utc).isoformat()}.
'''
(RUN/'UX-REPORT.md').write_text(report)
write(EVIDENCE/'MANIFEST.json',{'format':1,'created_at':dt.datetime.now(dt.timezone.utc).isoformat(),'origin':'LAB-015-ai-pilot-20261112T193728Z','source_paths':'Relative to original run root; no original file modified. Copied JSON may retain historical absolute provenance strings internally.','hash_algorithm':'SHA-256','entries':ENTRIES,'manifest_self_hash':'not included to avoid circular self-reference'})
print(json.dumps({'report':'UX-REPORT.md','findings':len(findings),'technical_bugs':0,'reproduction_cases':len(results),'evidence_files':len(ENTRIES),'evidence_bytes':sum(x['bytes'] for x in ENTRIES)},ensure_ascii=False))
