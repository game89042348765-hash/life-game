#!/usr/bin/env python3
"""Technical and acceptance checks for LifeGame Atlas Hybrid v2.1 (LAB-008-R1).
Uses invented data only. Verifies all 16 previous checks PLUS 7 dedicated acceptance checks for H1-H8
with reversed expectations (errors rejected, existing files preserved)."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import time
import zipfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("atlas", HERE / "atlas.py")
atlas = importlib.util.module_from_spec(spec)
spec.loader.exec_module(atlas)


def fixture(n):
    data = {k: [] for k in atlas.TABLES}
    for i in range(n):
        suffix = f"DEMO-{i:05d}"
        sid, fid, eid = "S-" + suffix, "F-" + suffix, "E-" + suffix
        cat, job = f"C{i % 32 + 1:02d}", f"J{i % 12 + 1:02d}"
        data["sources"].append({
            "id": sid,
            "url": "https://example.invalid/" + suffix,
            "title": "Вымышленный источник для проверки программы",
            "owner": "synthetic_fixture",
            "origin_group": "SYNTHETIC-" + suffix,
            "source_type": "other",
            "language": "ru",
            "retrieved_at": "2026-11-12T00:00:00+00:00",
            "accessed": True,
            "synthetic": True
        })
        data["findings"].append({
            "id": fid,
            "task_id": "SYNTHETIC-DEMO",
            "name": "Вымышленная находка " + suffix,
            "description": "Технические данные, не результат поиска.",
            "kind": "mechanism",
            "category_ids": [cat],
            "domain_code": "D08_GAME_CORE_ECONOMY",
            "phase_code": "P6_RECOVERY_ADAPTATION",
            "primary_friction_code": "F5_RELAPSE_SPIRAL",
            "source_ids": [sid],
            "verification": "verified",
            "claims": [{
                "type": "existence",
                "source_id": sid,
                "locator": "synthetic fixture",
                "text": "Этот факт вымышлен и используется только в тесте.",
                "basis": "paraphrase"
            }],
            "synthetic": True
        })
        data["elements"].append({
            "id": eid,
            "name": "Вымышленный механизм " + suffix,
            "description": "Пример структуры, не существующая рекомендация.",
            "kind": "mechanism",
            "primary_category": cat,
            "category_ids": [cat],
            "jobs": [job],
            "domain_code": "D08_GAME_CORE_ECONOMY",
            "phase_code": "P6_RECOVERY_ADAPTATION",
            "target_frictions": ["F5_RELAPSE_SPIRAL"],
            "paradigm_novelty": 3 if i % 10 == 0 else 2,
            "family_id": f"FAM-DEMO-{i // 2:05d}",
            "raw_ids": [fid],
            "source_ids": [sid],
            "mechanism": "Условное правило технического примера.",
            "mechanism_triad": {
                "trigger": "Синтетический триггер " + suffix,
                "core_rule": "Синтетическое правило " + suffix,
                "psychological_loop": "Синтетический контур " + suffix
            },
            "vendor_claim": "Вымышленное обещание автора L3 (изолировано от доказательств).",
            "benefit": "Не проверялась; вымышленное аналитическое поле.",
            "evidence_effect": "unknown",
            "evidence_grade": "EVID_B_THEORY_GROUNDED",
            "evidence_summary": "Реальные источники не изучались.",
            "contexts": ["synthetic"],
            "conditions": ["Только проверка формата"],
            "costs": [],
            "risks": ["Нельзя выдавать за исследование"],
            "alternatives": [],
            "questions": [],
            "existence": "verified",
            "review_status": "accepted",
            "risk_status": "reviewed",
            "selection_track": "main",
            "synthetic": True
        })
        data["merge_map"].append({
            "raw_id": fid,
            "element_ids": [eid],
            "decision": "canonical",
            "reason": "Соответствие один к одному только для технического теста."
        })
        for reviewer in ("A", "B"):
            scores = dict.fromkeys(atlas.DIMS, 3)
            scores["value"] = i % 4 + 1
            data["ratings"].append({
                "id": "R-" + reviewer + "-" + suffix,
                "element_id": eid,
                "reviewer_id": "synthetic-" + reviewer,
                "context_id": "synthetic-context-" + reviewer,
                "rubric_version": "2.1",
                "blind": True,
                "scores": scores,
                "rationales": dict.fromkeys(atlas.DIMS, "Заданное тестовое значение, не экспертная оценка."),
                "source_ids": [sid],
                "synthetic": True
            })
    return data


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--report")
    args = p.parse_args()
    cats, jobs, domains, phases, frictions = atlas.taxonomy(HERE.parent / "taxonomy.json")
    config = atlas.configuration()
    config.update({"mode": "synthetic_demo", "core": 3, "rare_gems_quota": 2, "target": 100})
    results = []

    def check(name, action):
        start = time.perf_counter()
        details = action()
        results.append({
            "check": name,
            "passed": True,
            "seconds": round(time.perf_counter() - start, 4),
            "details": details
        })

    def raises(action, text):
        try:
            action()
        except ValueError as exc:
            assert text in str(exc), f"Expected {text!r} in {str(exc)!r}"
        else:
            raise AssertionError("Expected failure: " + text)

    data = fixture(12)
    with tempfile.TemporaryDirectory(prefix="hybrid-v21-technical-") as temporary:
        root = Path(temporary)
        source = root / "dataset"
        atlas.write_data(source, data)

        def valid():
            assert atlas.validate(data, cats, jobs, True, domains, phases, frictions) == []
            return {"elements": 12, "ratings": 24}
        check("01_complete_schema_and_provenance_links", valid)

        def cli():
            run = root / "RUN.demo.json"
            atlas.dump(run, {"rubric_version": "2.1", "taxonomy_version": "2.1", "selection": config})
            before = atlas.snapshot_hashes(source)
            process = subprocess.run(
                [sys.executable, str(HERE / "atlas.py"), "rank", str(source), "--config", str(run), "--out", str(root / "release")],
                capture_output=True, text=True, timeout=60
            )
            assert process.returncode == 0, process.stderr
            result = json.loads(process.stdout)
            assert result["status"] == "synthetic_demo_not_research"
            assert result["selected"] == 12 and result["target_reached"] is False
            audit = json.loads((root / "release/audit.json").read_text())
            assert len(audit["sensitivity"]) == 6
            assert "full_atlas_jaccard_with_baseline" in audit["sensitivity"]["baseline"]
            assert "full_atlas_ids" in audit["sensitivity"]["baseline"]
            assert atlas.snapshot_hashes(source) == before
            assert "ТЕХНИЧЕСКИЙ ПРИМЕР" in (root / "release/ATLAS-DRAFT.md").read_text()
            return result
        check("02_real_cli_outputs_hashes_and_incomplete_target", cli)

        def unknown():
            changed = copy.deepcopy(data)
            changed["ratings"][0]["scores"]["value"] = None
            assert not atlas.validate(changed, cats, jobs, True, domains, phases, frictions)
            ranked, selected, audit = atlas.calculate(changed, cats, jobs, config)
            eid = changed["elements"][0]["id"]
            assert eid not in {r["id"] for r in ranked}
            assert any(r["id"] == eid and "fewer_than_two_complete_blind_reviews" in r["reasons"] for r in audit["excluded"])
            return "null stays unknown; candidate not promoted"
        check("03_unknown_not_zero_or_imputed", unknown)

        def invalid():
            cases = []
            changed = copy.deepcopy(data)
            changed["elements"][0]["source_ids"] = ["MISSING"]
            cases.append(changed)
            changed = copy.deepcopy(data)
            changed["merge_map"].pop()
            cases.append(changed)
            changed = copy.deepcopy(data)
            changed["sources"][0]["accessed"] = False
            cases.append(changed)
            changed = copy.deepcopy(data)
            changed["ratings"][0]["scores"]["value"] = True
            cases.append(changed)
            for changed in cases:
                assert atlas.validate(changed, cats, jobs, True, domains, phases, frictions)
            return "missing source, lost disposition, unviewed existence, boolean score rejected"
        check("04_critical_invalid_inputs_rejected", invalid)

        def independence():
            for key in ("reviewer_id", "context_id"):
                changed = copy.deepcopy(data)
                changed["ratings"][1][key] = changed["ratings"][0][key]
                assert atlas.validate(changed, cats, jobs, True, domains, phases, frictions)
            changed = copy.deepcopy(data)
            changed["ratings"][0]["rubric_version"] = "9.0"
            assert atlas.validate(changed, cats, jobs, True, domains, phases, frictions)
            return "duplicate reviewer/context and wrong rubric rejected"
        check("05_review_identity_and_version", independence)

        def gates():
            changed = copy.deepcopy(data)
            changed["elements"][0]["kind"] = "method_system"
            changed["elements"][1]["selection_track"] = "reference"
            changed["elements"][2]["risk_status"] = "unresolved_high"
            changed["elements"][3]["existence"] = "disputed"
            for r in changed["ratings"]:
                if r["element_id"] == changed["elements"][4]["id"]:
                    r["scores"] = dict.fromkeys(atlas.DIMS, 0)
            assert not atlas.validate(changed, cats, jobs, True, domains, phases, frictions)
            ranked, selected, audit = atlas.calculate(changed, cats, jobs, config)
            excluded = {r["id"] for r in audit["excluded"]}
            assert {e["id"] for e in changed["elements"][:4]} <= excluded
            assert changed["elements"][4]["id"] in audit["below_quality_floor"]
            assert changed["elements"][4]["id"] not in {s["id"] for s in selected}
            return "composites, reference, unresolved risks and disputed existence blocked; low quality not used as filler"
        check("06_eligibility_and_quality_floor", gates)

        def disagreement():
            changed = copy.deepcopy(data)
            changed["ratings"][0]["scores"]["value"] = 1
            changed["ratings"][1]["scores"]["value"] = 4
            eid = changed["elements"][0]["id"]
            _, _, audit = atlas.calculate(changed, cats, jobs, config)
            assert any(e["id"] == eid and "unresolved_rating_disagreement" in e["reasons"] for e in audit["excluded"])
            changed["decisions"].append({
                "id": "D-SYNTHETIC",
                "element_id": eid,
                "type": "rating_resolution",
                "resolved": True,
                "reason": "Технический пример фиксации разрешённого расхождения.",
                "reviewer_ids": ["synthetic-A", "synthetic-B"],
                "source_ids": []
            })
            assert not atlas.validate(changed, cats, jobs, True, domains, phases, frictions)
            ranked, _, _ = atlas.calculate(changed, cats, jobs, config)
            row = next(r for r in ranked if r["id"] == eid)
            assert row["Q_min"] < row["Q_max"]
            return "resolution required; original range retained"
        check("07_disagreement_gate_and_auditable_resolution", disagreement)

        def stable():
            baseline = atlas.calculate(data, cats, jobs, config)
            changed = copy.deepcopy(data)
            rng = random.Random(20261112)
            for rows in changed.values():
                rng.shuffle(rows)
            result = atlas.calculate(changed, cats, jobs, config)
            assert baseline[1] == result[1]
            assert [r["id"] for r in baseline[0]] == [r["id"] for r in result[0]]
            assert baseline[2]["sensitivity"] == result[2]["sensitivity"]
            return "rank, selection and sensitivity independent of input row order"
        check("08_deterministic_with_shuffled_input", stable)

        def merging():
            merged = root / "merged"
            result = atlas.merge([source, source], merged, cats, jobs, domains, phases, frictions)
            assert result["elements"] == 12
            changed = copy.deepcopy(data)
            changed["elements"][0]["description"] = "CONFLICT"
            other = root / "conflict"
            atlas.write_data(other, changed)
            refused = root / "refused"
            raises(lambda: atlas.merge([source, other], refused, cats, jobs, domains, phases, frictions), "Conflicting ID")
            assert not refused.exists()
            return "exact IDs coalesced; conflicting revision stops without output"
        check("09_merge_no_silent_overwrite", merging)

        def integrity():
            bundle = root / "bundle"
            bundle.mkdir()
            (bundle / "a.txt").write_text("original", encoding="utf-8")
            atlas.manifest(bundle, "FILES.json")
            assert atlas.manifest(bundle, "FILES.json", True)["verified_files"] == 1
            (bundle / "a.txt").write_text("changed", encoding="utf-8")
            raises(lambda: atlas.manifest(bundle, "FILES.json", True), "Integrity mismatch")
            raises(lambda: atlas.calculate(data, cats, jobs, atlas.configuration()), "Synthetic examples")
            d_no_flag = copy.deepcopy(data)
            for tbl in d_no_flag.values():
                for row in tbl:
                    row.pop("synthetic", None)
            raises(lambda: atlas.calculate(d_no_flag, cats, jobs, atlas.configuration()), "reserved .invalid/example URLs")
            return "byte change caught; synthetic fixtures and .invalid URLs blocked from research mode"
        check("10_integrity_and_demo_separation", integrity)

        def partial_rating_disagreement_caught():
            changed = copy.deepcopy(data)
            eid = changed["elements"][0]["id"]
            changed["ratings"].append({
                "id": "R-C-PARTIAL",
                "element_id": eid,
                "reviewer_id": "synthetic-C",
                "context_id": "synthetic-context-C",
                "rubric_version": "2.1",
                "blind": True,
                "scores": {"value": 4, "burden": 3, "long_term": 3, "adaptability": 3, "agency": 3, "composability": None},
                "rationales": dict.fromkeys(atlas.DIMS, "Partial review with sharp disagreement on value"),
                "source_ids": [changed["sources"][0]["id"]],
                "synthetic": True
            })
            _, _, audit = atlas.calculate(changed, cats, jobs, config)
            assert any(e["id"] == eid and "unresolved_rating_disagreement" in e["reasons"] for e in audit["excluded"])
            changed["decisions"].append({
                "id": "D-FAKE-RES",
                "element_id": eid,
                "type": "rating_resolution",
                "resolved": True,
                "reason": "Omitted C",
                "reviewer_ids": ["synthetic-A", "synthetic-B"],
                "source_ids": []
            })
            errs = atlas.validate(changed, cats, jobs, True, domains, phases, frictions)
            assert any("resolution omits disagreeing reviewers: synthetic-C" in err for err in errs), str(errs)
            return "P0 Fixes #1 & #2 verified: partial blind rating disagreement caught; incomplete resolution rejected"
        check("11_partial_blind_disagreement_and_strict_resolution_gate", partial_rating_disagreement_caught)

        def non_penalizing_multilabel_and_rare_lane():
            changed = copy.deepcopy(data)
            changed["elements"][4]["jobs"] = ["J12"]
            changed["elements"][5]["jobs"] = ["J12", "J01", "J02"]
            _, selected, _ = atlas.calculate(changed, cats, jobs, config)
            tiers = {s["id"]: s["tier"] for s in selected}
            assert "rare_lateral_gem" in tiers.values()
            return "P0 Fix #3 & P1 Rare Lane verified: protected rare_lateral_gem tier active and multi-label elements not penalized"
        check("12_protected_rare_gems_lane_and_non_penalizing_gain", non_penalizing_multilabel_and_rare_lane)

        def composite_and_quarantine_strictness():
            changed = copy.deepcopy(data)
            changed["merge_map"][0]["decision"] = "quarantined"
            errs1 = atlas.validate(changed, cats, jobs, True, domains, phases, frictions)
            assert any("quarantined/out_of_scope mapping must have empty element_ids" in e for e in errs1)

            changed2 = copy.deepcopy(data)
            changed2["elements"][0]["kind"] = "method_system"
            changed2["merge_map"][0]["decision"] = "composite"
            errs2 = atlas.validate(changed2, cats, jobs, True, domains, phases, frictions)
            assert any("composite method_system lacks contains relations" in e for e in errs2)
            return "P0 Fix #4a/4b verified: quarantined non-empty targets and unlinked composite method_systems rejected"
        check("13_quarantine_and_composite_contains_enforcement", composite_and_quarantine_strictness)

        def sharding_and_blind_packet_prep():
            shard_out = root / "shards"
            s_res = atlas.shard_findings(source, shard_out, HERE.parent / "taxonomy.json")
            assert s_res["total_findings"] == 12 and s_res["shards_count"] >= 1
            assert (shard_out / "compact_findings_index_part001.txt").exists()

            blind_out = root / "blind_elements.jsonl"
            b_res = atlas.prepare_blind_packet(source, blind_out, HERE.parent / "taxonomy.json")
            assert b_res["blind_elements_prepared"] == 12
            first_blind = json.loads(blind_out.read_text(encoding="utf-8").splitlines()[0])
            assert "scores" not in first_blind and "benefit" not in first_blind
            return "P1 Sharding & Blind Packet preparation verified"
        check("14_cross_domain_sharding_and_blind_packet_sterilization", sharding_and_blind_packet_prep)

        def tolerant_truncated_jsonl_handling():
            trunc_dir = root / "trunc_dataset"
            atlas.write_data(trunc_dir, data)
            with (trunc_dir / "findings.jsonl").open("a", encoding="utf-8") as f:
                f.write('{"id": "F-TRUNC", "name": "Оборванная строка без закрытия...\n')
            loaded, malformed = atlas.load(trunc_dir, tolerant=True)
            assert len(loaded["findings"]) == 12 and len(malformed) == 1
            assert malformed[0]["table"] == "findings"
            return "P1 Tolerant JSONL loader verified: 12 valid rows preserved, 1 truncated line isolated"
        check("15_tolerant_truncated_jsonl_recovery", tolerant_truncated_jsonl_handling)

        def scale():
            large = fixture(10000)
            assert atlas.validate(large, cats, jobs, True, domains, phases, frictions) == []
            cfg = atlas.configuration()
            cfg["mode"] = "synthetic_demo"
            ranked, selected, audit = atlas.calculate(large, cats, jobs, cfg)
            assert len(ranked) == 10000 and len(selected) == 200
            assert len({s["id"] for s in selected}) == 200
            assert not audit["missing_categories"] and not audit["missing_jobs"]
            return {"synthetic_elements": 10000, "synthetic_ratings": 20000, "selected": 200, "real_web_sources": 0}
        check("16_ten_thousand_synthetic_elements_hybrid_v2", scale)

        # --- NEW LAB-008-R1 ACCEPTANCE CHECKS (17 to 23) WITH REVERSED EXPECTATIONS ---
        def h1_manifest_ignores_pycache():
            bundle_dir = root / "h1_bundle"
            (bundle_dir / "tools" / "__pycache__").mkdir(parents=True)
            (bundle_dir / "tools" / "atlas.py").write_text("# code\n", encoding="utf-8")
            (bundle_dir / "tools" / "__pycache__" / "atlas.cpython-311.pyc").write_bytes(b"\x00\x01\x02")
            atlas.manifest(bundle_dir, "BUNDLE_MANIFEST.json", checking=False)
            # Now simulate extracting a clean ZIP where __pycache__ was not included
            (bundle_dir / "tools" / "__pycache__" / "atlas.cpython-311.pyc").unlink()
            (bundle_dir / "tools" / "__pycache__").rmdir()
            ver = atlas.manifest(bundle_dir, "BUNDLE_MANIFEST.json", checking=True)
            assert ver["verified_files"] == 1
            return "H1 fixed: __pycache__ never enters BUNDLE_MANIFEST.json; clean unpacked archive verifies with exit 0"
        check("17_H1_unpacked_zip_manifest_integrity", h1_manifest_ignores_pycache)

        def h2_aggregation_unity():
            d_h2 = fixture(1)
            d_h2["ratings"][0]["scores"] = dict.fromkeys(atlas.DIMS, 3)
            d_h2["ratings"][0]["scores"]["value"] = 2
            d_h2["ratings"][1]["scores"] = dict.fromkeys(atlas.DIMS, 3)
            d_h2["ratings"][1]["scores"]["value"] = 3
            # Add partial review with value=3 and composability=None (no sharp disagreement)
            r_part = copy.deepcopy(d_h2["ratings"][0])
            r_part.update(id="R-PART", reviewer_id="reviewer-C", context_id="context-C")
            r_part["scores"] = dict.fromkeys(atlas.DIMS, 3)
            r_part["scores"]["value"] = 3
            r_part["scores"]["composability"] = None
            d_h2["ratings"].append(r_part)

            ranked, _, _ = atlas.calculate(d_h2, cats, jobs, config)
            assert ranked[0]["Q"] == 71.25, f"Expected 71.25, got {ranked[0]['Q']}"
            assert ranked[0]["known_scores_per_dim"]["value"] == 3
            assert ranked[0]["known_scores_per_dim"]["composability"] == 2
            return {"Q": ranked[0]["Q"], "known_scores_per_dim": ranked[0]["known_scores_per_dim"]}
        check("18_H2_aggregation_policy_unity", h2_aggregation_unity)

        def h3_bounded_sharding_10k_and_oversized():
            raw_10k = {k: [] for k in atlas.TABLES}
            seed = fixture(1)
            raw_10k["sources"] = copy.deepcopy(seed["sources"])
            for i in range(10000):
                f = copy.deepcopy(seed["findings"][0])
                f["id"] = f"F-RAW-{i:05d}"
                if i == 500:
                    # Make one oversized record (> 60 KB) to verify non-truncated oversized handling
                    f["description"] = "Длинное описание без потери смысла. " * 2000
                raw_10k["findings"].append(f)
            ds_10k = root / "raw_10k"
            atlas.write_data(ds_10k, raw_10k)
            out_10k = root / "shards_10k"
            summary = atlas.shard_findings(
                ds_10k, out_10k, HERE.parent / "taxonomy.json",
                max_records=100, max_bytes=60000, index_max_records=1000
            )
            receipt = json.loads((out_10k / "shards_manifest.json").read_text(encoding="utf-8"))
            assert summary["total_findings"] == 10000
            assert summary["shards_count"] >= 100
            assert receipt["largest_part_records"] <= 100
            assert receipt["largest_standard_part_bytes"] <= 60000
            assert len(receipt["oversized_single_records"]) == 1
            assert receipt["oversized_single_records"][0]["id"] == "F-RAW-00500"
            # Verify all 10,000 IDs accounted for exactly once and sources file attached
            all_ids = [fid for part in receipt["shards"].values() for fid in part["finding_ids"]]
            assert len(all_ids) == 10000 and len(set(all_ids)) == 10000
            first_part = next(iter(receipt["shards"].values()))
            assert (out_10k / first_part["sources_file"]).exists()
            return {
                "total_findings": 10000,
                "shard_parts": summary["shards_count"],
                "largest_part_records": receipt["largest_part_records"],
                "oversized_isolated": len(receipt["oversized_single_records"])
            }
        check("19_H3_bounded_shards_10k_same_bucket_and_oversized", h3_bounded_sharding_10k_and_oversized)

        def h4_h5_shard_safety_and_path_containment():
            # H4: Re-running shard on existing output must fail safely without modifying existing files
            existing_out = root / "shards"
            index_part = existing_out / "compact_findings_index_part001.txt"
            before_bytes = index_part.read_bytes()
            raises(
                lambda: atlas.shard_findings(source, existing_out, HERE.parent / "taxonomy.json"),
                "Shard output directory already exists"
            )
            assert index_part.read_bytes() == before_bytes

            # H5: Unsafe phase_code with path traversal and pre-existing SHARD_X folder
            unsafe = copy.deepcopy(fixture(1))
            unsafe["findings"][0]["phase_code"] = "X/../../escaped"
            unsafe["findings"][0]["primary_friction_code"] = "GENERAL"
            unsafe_dir = root / "unsafe_data"
            atlas.write_data(unsafe_dir, unsafe)
            target = root / "unsafe_output"
            (target / "SHARD_X").mkdir(parents=True)
            marker = root / "escaped__GENERAL.jsonl"
            marker.write_text("CONTROLLED TEMPORARY MARKER", encoding="utf-8")
            # Both existing target and invalid phase_code must be rejected before any write
            raises(
                lambda: atlas.shard_findings(unsafe_dir, target, HERE.parent / "taxonomy.json"),
                "Shard output directory already exists"
            )
            target2 = root / "unsafe_output_new"
            raises(
                lambda: atlas.shard_findings(unsafe_dir, target2, HERE.parent / "taxonomy.json"),
                "Invalid input dataset for sharding"
            )
            assert not target2.exists()
            assert marker.read_text(encoding="utf-8") == "CONTROLLED TEMPORARY MARKER"
            return "H4 & H5 fixed: existing output refused; path traversal rejected; marker untouched"
        check("20_H4_H5_shard_no_overwrite_and_path_containment", h4_h5_shard_safety_and_path_containment)

        def h6_prepare_blind_safety():
            el_path = source / "elements.jsonl"
            before_bytes = el_path.read_bytes()
            # Aliasing input elements.jsonl must be rejected before touching the file
            raises(
                lambda: atlas.prepare_blind_packet(source, el_path, HERE.parent / "taxonomy.json"),
                "already exists"
            )
            raises(
                lambda: atlas.prepare_blind_packet(source, source / "new_blind_inside_input.jsonl", HERE.parent / "taxonomy.json"),
                "cannot be inside or equal to the input dataset directory"
            )
            assert el_path.read_bytes() == before_bytes
            return "H6 fixed: prepare-blind refuses existing files and paths inside input dataset"
        check("21_H6_prepare_blind_refuses_overwrite_and_aliasing", h6_prepare_blind_safety)

        def h7_rare_quota_validation():
            for bad_val in (-1, -5, True, False, 1.5, "10", 150):
                bad_run = root / f"bad_quota_{bad_val}.json"
                atlas.dump(bad_run, {
                    "rubric_version": "2.1",
                    "taxonomy_version": "2.1",
                    "selection": {"mode": "synthetic_demo", "core": 10, "target": 100, "rare_gems_quota": bad_val}
                })
                raises(lambda: atlas.configuration(bad_run), "rare_gems_quota must be integer")

            # Quota = 0 should allocate 0 rare_lateral_gem seats
            zero_run = root / "zero_quota.json"
            atlas.dump(zero_run, {
                "rubric_version": "2.1",
                "taxonomy_version": "2.1",
                "selection": {"mode": "synthetic_demo", "core": 3, "target": 100, "rare_gems_quota": 0}
            })
            cfg_zero = atlas.configuration(zero_run)
            _, sel_zero, _ = atlas.calculate(data, cats, jobs, cfg_zero)
            assert sum(1 for s in sel_zero if s["tier"] == "rare_lateral_gem") == 0
            return "H7 fixed: negative, boolean, float, string, and oversized quotas rejected; 0 quota yields 0 rare seats"
        check("22_H7_rare_gems_quota_strict_validation", h7_rare_quota_validation)

        def h8_instructions_and_paste_sync():
            pkg_root = HERE.parent
            scoring_txt = (pkg_root / "SCORING.md").read_text(encoding="utf-8").strip()
            dc_txt = (pkg_root / "DATA_CONTRACT.md").read_text(encoding="utf-8").strip()
            assert "для последних двух возможен пустой список" not in dc_txt
            assert "список `element_ids` обязан быть строго пустым (`[]`)" in dc_txt
            for paste_name in ("02-ANALYZE.txt", "03-SELECT.txt", "05-COORDINATE.txt"):
                ptxt = (pkg_root / "PASTE" / paste_name).read_text(encoding="utf-8")
                assert scoring_txt in ptxt, f"SCORING.md out of sync in PASTE/{paste_name}"
                assert dc_txt in ptxt, f"DATA_CONTRACT.md out of sync in PASTE/{paste_name}"
            for st_path in sorted((pkg_root / "starter_tasks").glob("*.json")):
                st = json.loads(st_path.read_text(encoding="utf-8"))
                assert st["protocol_version"] == "2.1"
                for rel_file, expected_sha in st["input_hashes"].items():
                    actual_sha = hashlib.sha256((pkg_root / rel_file).read_bytes()).hexdigest()
                    assert actual_sha == expected_sha, f"Hash mismatch in {st_path.name} for {rel_file}"
            return "H8 fixed: PASTE/*.txt, DATA_CONTRACT.md, SCORING.md, and starter_tasks hashes 100% synchronized"
        check("23_H8_shared_instructions_and_paste_sync", h8_instructions_and_paste_sync)

    report = {
        "status": "technical_checks_only_not_research",
        "version": "2.1-hybrid",
        "checks_passed": len(results),
        "checks": results,
        "tool_sha256": atlas.sha(HERE / "atlas.py"),
        "verifier_sha256": atlas.sha(__file__),
        "python": sys.version.split()[0],
        "network_requests": 0
    }
    if args.report:
        path = Path(args.report)
        atlas.dump(path, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
